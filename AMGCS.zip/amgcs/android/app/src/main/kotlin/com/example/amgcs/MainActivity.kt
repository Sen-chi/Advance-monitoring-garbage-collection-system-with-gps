package com.example.amgcs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
