import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io'; // For File

// FIX: Ensure image_picker is imported correctly
import 'package:image_picker/image_picker.dart'; // For image picking

import 'package:path/path.dart' as path; // For getting filename

// FIX: Move this import to the top and make it relative
// Need the LoginScreen definition available for navigation back.
// You can either import it or define it here if it's simple.
// Assuming LoginScreen is in main.dart and main.dart is imported.
// import 'package:amgcs_app/main.dart'; // Adjust this import based on your project structure
import 'main.dart'; // Assuming main.dart is in the same directory (lib/)


// Model to hold profile data
class UserProfile {
  final int userId;
  final String username;
  final String email;
  final String? firstName;
  final String? middleName;
  final String? lastName;
  final String? contactNumber;
  final String? profilePictureUrl; // Added field

  UserProfile({
    required this.userId,
    required this.username,
    required this.email,
    this.firstName,
    this.middleName,
    this.lastName,
    this.contactNumber,
    this.profilePictureUrl,
  });

  // Factory constructor to create a UserProfile from JSON
  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      userId: json['user_id'],
      username: json['username'],
      email: json['email'],
      firstName: json['first_name'],
      middleName: json['middle_name'],
      lastName: json['last_name'],
      contactNumber: json['contact_number'],
      profilePictureUrl: json['profile_picture_url'],
    );
  }
}

class ProfileScreen extends StatefulWidget {
  final int userId; // Pass the logged-in user ID to this screen

  ProfileScreen({Key? key, required this.userId}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  UserProfile? _userProfile;
  bool _isLoading = true;
  File? _pickedImageFile; // To hold the image file picked by the user

  // --- Backend API URLs ---
  // !!! CHANGE THESE TO YOUR ACTUAL SERVER IP/DOMAIN !!!
  final String _fetchProfileApiUrl = 'http://192.168.1.65/amgcs app/fetch_profile.php';
  final String _uploadProfilePictureApiUrl = 'http://192.168.1.65/amgcs app/upload_profile_picture.php';
  // Base URL for accessing uploaded images
  final String _imageBaseUrl = 'http://192.168.1.65/amgcs app/uploads/profile_pictures/'; // Make sure this matches your PHP script's save location

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse(_fetchProfileApiUrl),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, int>{
          'user_id': widget.userId, // Send the user ID
        }),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = jsonDecode(response.body);
        if (responseBody['success'] == true) {
          setState(() {
            // Assuming the JSON structure matches the UserProfile model
            _userProfile = UserProfile.fromJson(responseBody['data']);
          });
        } else {
          // Handle error fetching data
          print('Failed to load profile: ${responseBody['message']}');
          // Use a Builder to ensure context is available for ScaffoldMessenger
          if (mounted) { // Check if widget is still in the tree
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(responseBody['message'] ?? 'Failed to load profile data')),
            );
          }
        }
      } else {
        // Handle non-200 status codes
        print('Server error fetching profile: ${response.statusCode}');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Server error: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      // Handle network errors
      print('Error fetching profile: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to connect to server to fetch profile.')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _pickImage() async {
    // FIX: ImagePicker() and ImageSource are now available due to correct import
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery); // Or ImageSource.camera

    if (pickedFile != null) {
      setState(() {
        _pickedImageFile = File(pickedFile.path);
      });
      // Optionally, upload immediately after picking
      _uploadImage(_pickedImageFile!);
    } else {
      print('No image selected.');
    }
  }

  Future<void> _uploadImage(File imageFile) async {
    setState(() {
      _isLoading = true; // Show loading indicator during upload
    });

    try {
      // Create a multipart request
      var request = http.MultipartRequest(
        'POST',
        Uri.parse(_uploadProfilePictureApiUrl),
      );

      // Add the user ID field
      request.fields['user_id'] = widget.userId.toString();

      // Add the image file
      request.files.add(await http.MultipartFile.fromPath(
        'profile_picture', // This should match the name expected by your PHP script ($_FILES['profile_picture'])
        imageFile.path,
        filename: path.basename(imageFile.path), // Use the original filename
      ));

      // Send the request
      var streamedResponse = await request.send();

      // Listen for the response
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = jsonDecode(response.body);
        if (responseBody['success'] == true) {
          print('Profile picture uploaded successfully!');
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Profile picture updated!')),
            );
          }
          // Refresh profile data to show the new image
          _fetchProfileData();
          // Clear the picked image file state after successful upload
          setState(() {
            _pickedImageFile = null;
          });
        } else {
          print('Failed to upload profile picture: ${responseBody['message']}');
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(responseBody['message'] ?? 'Failed to upload picture')),
            );
          }
        }
      } else {
        print('Server error uploading picture: ${response.statusCode}');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Server error: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      print('Error uploading picture: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to upload picture. Please try again.')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false; // Hide loading indicator
        });
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    // Determine which image source to use (picked image, fetched URL, or default)
    Widget profileImageWidget;
    if (_pickedImageFile != null) {
      // Use the image picked by the user immediately
      profileImageWidget = Image.file(_pickedImageFile!, fit: BoxFit.cover);
    } else if (_userProfile != null && _userProfile!.profilePictureUrl != null && _userProfile!.profilePictureUrl!.isNotEmpty) {
      // Use the image URL fetched from the backend
      profileImageWidget = Image.network(
        '$_imageBaseUrl${_userProfile!.profilePictureUrl}', // Construct the full URL
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          // Fallback if network image fails
          return Icon(Icons.account_circle, size: 80, color: Colors.grey[700]);
        },
      );
    } else {
      // Use a default icon or image
      profileImageWidget = Icon(Icons.account_circle, size: 80, color: Colors.grey[700]); // Default icon
      // Or use a default asset image:
      // profileImageWidget = Image.asset('assets/images/default_profile.png', fit: BoxFit.cover);
    }


    return Scaffold(
      // Using AppBar for a standard screen header
      appBar: AppBar(
        title: Text('Profile'),
        backgroundColor: Colors.green[700], // Match theme color
      ),
      body: _isLoading && _userProfile == null // Show initial loader if data is being fetched for the first time
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            // --- Profile Header Section ---
            Container(
              padding: const EdgeInsets.all(20.0),
              color: Colors.white, // White background for the header section
              child: Column(
                children: [
                  GestureDetector( // Make the profile picture tappable
                    onTap: _pickImage, // Call the image picker function
                    child: Stack( // Use Stack to layer the image and edit icon
                      alignment: Alignment.bottomRight,
                      children: [
                        CircleAvatar(
                          radius: 40, // Adjust size as needed
                          backgroundColor: Colors.grey[300], // Placeholder background
                          child: ClipOval( // Clip the image to a circle
                            child: profileImageWidget, // The widget determined above
                          ),
                        ),
                        // Optional: Add an edit icon overlay
                        Positioned(
                          right: 0,
                          bottom: 0,
                          child: CircleAvatar(
                            radius: 12,
                            backgroundColor: Colors.green[700],
                            child: Icon(Icons.edit, size: 14, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    // Display Full Name if available, otherwise Username
                    (_userProfile?.firstName != null && _userProfile?.lastName != null)
                        ? '${_userProfile!.firstName!} ${_userProfile!.middleName != null ? _userProfile!.middleName! + ' ' : ''}${_userProfile!.lastName!}'
                        : (_userProfile?.username ?? 'Loading...'), // Fallback to username or loading
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  Text(
                    _userProfile?.email ?? 'Loading...',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                  // Display contact number if available
                  if (_userProfile?.contactNumber != null && _userProfile!.contactNumber!.isNotEmpty) // Also check if not empty
                    Text(
                      'Contact: ${_userProfile!.contactNumber!}',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20), // Space after header

            // --- Profile Options List ---
            Container(
              color: Colors.white, // White background for the list section
              child: Column( // Use Column for ListTiles
                children: [
                  // Account Tile
                  ListTile(
                    leading: Icon(Icons.account_circle_outlined, color: Colors.grey[700]),
                    title: Text('Account'),
                    trailing: Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
                    onTap: () {
                      // TODO: Navigate to Account details screen
                      print("Account tapped");
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Account settings (Not implemented)')),
                      );
                    },
                  ),
                  Divider(height: 0), // Visual separator

                  // Edit Profile Tile
                  ListTile(
                    leading: Icon(Icons.edit_outlined, color: Colors.grey[700]),
                    title: Text('Edit profile'),
                    trailing: Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
                    onTap: () {
                      // TODO: Navigate to Edit Profile screen
                      print("Edit profile tapped");
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Edit profile (Not implemented, you can add fields here)')),
                      );
                      // A dedicated EditProfileScreen would be better for editing text fields
                      // For now, picture upload is handled directly here via tapping the image.
                    },
                  ),
                  Divider(height: 0),

                  // Notifications Tile
                  ListTile(
                    leading: Icon(Icons.notifications_outlined, color: Colors.grey[700]),
                    title: Text('Notifications'),
                    trailing: Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
                    onTap: () {
                      // TODO: Navigate to Notifications settings
                      print("Notifications tapped");
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Notification settings (Not implemented)')),
                      );
                    },
                  ),
                  Divider(height: 0),

                  // Log out Tile
                  ListTile(
                    leading: Icon(Icons.logout, color: Colors.redAccent), // Different color for logout
                    title: Text('Log out', style: TextStyle(color: Colors.redAccent)),
                    trailing: Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
                    onTap: () {
                      // TODO: Implement Log out logic
                      print("Log out tapped");
                      // Clear any stored session data (like user ID, tokens)
                      // Navigate back to the LoginScreen
                      // FIX: LoginScreen is now available due to correct import
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => LoginScreen()), // LoginScreen should be accessible
                            (Route<dynamic> route) => false, // Remove all previous routes
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}