import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// Import your new dashboard screen file
import 'dashboard_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AMGCS App', // Changed title
      // Start with the LoginScreen
      home: LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- Your existing LoginScreen StatefulWidget definition ---
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}
// --- End of LoginScreen definition ---


// --- Your existing _LoginScreenState definition ---
class _LoginScreenState extends State<LoginScreen> {
  // Add TextEditingControllers to get text field values
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // State variable to show loading indicator
  bool _isLoading = false;

  // --- Function to handle Login ---
  Future<void> _login() async {
    setState(() {
      _isLoading = true; // Show loading indicator
    });

    final String username = _usernameController.text.trim();
    final String password = _passwordController.text.trim();

    // --- REPLACE WITH YOUR BACKEND API URL ---
    // Ensure this URL is correct and accessible from your device/emulator
    final String apiUrl = 'http://192.168.1.65/amgcs app/login.php';

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter username and password')),
      );
      setState(() {
        _isLoading = false;
      });
      return; // Stop if fields are empty
    }


    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        // Send username and password in the request body as JSON
        body: jsonEncode(<String, String>{
          'username': username,
          'password': password,
        }),
      );

      setState(() {
        _isLoading = false; // Hide loading indicator
      });

      if (response.statusCode == 200) {
        // Parse the JSON response from the backend
        final Map<String, dynamic> responseBody = jsonDecode(response.body);

        if (responseBody['success'] == true) {
          print('Login Successful!');
          // --- Get user_id from the response and navigate ---
          // Assuming your login.php returns 'user_id' in the success response
          final int? userId = responseBody['user_id']; // Access the user_id key

          if (userId != null) {
            // Navigate to the DashboardScreen and pass the user ID
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => DashboardScreen(userId: userId), // Pass the obtained user ID
              ),
            );
          } else {
            // Handle case where login was successful but user_id is missing in response
            print('Login successful, but user ID not received.');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Login successful, but user data incomplete. Please contact support.')),
            );
            // You might want to add a logout here or prevent further access
          }


        } else {
          // Login failed (backend reported error)
          final String errorMessage = responseBody['message'] ?? 'Login failed';
          print('Login Failed: $errorMessage');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(errorMessage)),
          );
        }
      } else {
        // Handle non-200 status codes from the server
        print('Server error: ${response.statusCode}');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Server error: ${response.statusCode}')),
        );
      }
    } catch (e) {
      // Handle network errors (e.g., server unreachable)
      print('Error during login: $e');
      setState(() {
        _isLoading = false; // Ensure loading is off even on error
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to connect to server. Please try again.')),
      );
    }
  }
  // --- End of Login Function ---


  @override
  void dispose() {
    // Clean up the controllers when the widget is disposed
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // --- Your existing LoginScreen build method ---
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Center(
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/gso.png', // Make sure this path is correct
                      width: 150,
                      height: 150,
                      // Handle potential errors loading the image (optional, but good practice)
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(Icons.account_circle, size: 150, color: Colors.grey); // Fallback icon
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 40.0),

                TextField(
                  controller: _usernameController,
                  decoration: InputDecoration(
                    hintText: 'Username',
                    filled: true,
                    fillColor: Colors.grey[200],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                  ),
                ),
                const SizedBox(height: 15.0),

                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    filled: true,
                    fillColor: Colors.grey[200],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                  ),
                ),
                const SizedBox(height: 25.0),

                ElevatedButton(
                  onPressed: _isLoading ? null : _login, // Disable button while loading
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[700],
                    padding: const EdgeInsets.symmetric(vertical: 15.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: _isLoading // Show loader if _isLoading is true
                      ? SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      strokeWidth: 2.0,
                    ),
                  )
                      : const Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 20.0),

              ],
            ),
          ),
        ),
      ),
    );
    // --- End of LoginScreen build method ---
  }
}
// --- End of _LoginScreenState definition ---

// The DashboardScreen definition is expected to be in dashboard_screen.dart
// It now needs to accept an 'userId' argument.