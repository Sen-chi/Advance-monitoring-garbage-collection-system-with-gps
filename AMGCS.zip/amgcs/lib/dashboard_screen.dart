// dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:amgcs/profile_screen.dart'; // Import the profile screen

// Add this import if LoginScreen is in main.dart and you need to navigate back
// import 'package:amgcs/main.dart'; // Adjust based on your project structure

// Update DashboardScreen to accept userId
class DashboardScreen extends StatefulWidget {
  // Added const keyword
  const DashboardScreen({Key? key, required this.userId}) : super(key: key);
  final int userId; // Accept user ID

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0; // To track selected bottom nav item

  // Define the list of widgets that will be displayed based on the selected index
  // This list is now defined as a getter or method *outside* of initState,
  // and will be accessed from the build method, ensuring valid context.
  List<Widget> _pages(BuildContext context) { // Pass context here
    return [
      _buildDashboardContent(context), // Pass context to your content builder
      ProfileScreen(userId: widget.userId), // Pass user ID
    ];
  }


  @override
  void initState() {
    super.initState();
    // REMOVE the initialization of _screens here.
    // Any code that depends on InheritedWidgets like MediaQuery.of(context)
    // cannot go in initState.
  }

  // Function to handle bottom navigation bar taps
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    // BASED ON YOUR ORIGINAL CODE'S COMMENT AND Navigator.push call:
    // If the intent for the Profile item (index 1) is to navigate to a *new* screen
    // using Navigator.push, rather than just swapping content within the bottom nav,
    // you would handle that here and perhaps *not* change _selectedIndex for index 1.
    // However, using _selectedIndex for both suggests swapping content.
    // Let's assume the bottom nav is for swapping body content within this screen.
    // In this case, the Navigator.push below is incorrect and should be removed.
    /*
    if (index == 1) {
       // REMOVE this line if bottom nav is for swapping body content:
       // Navigator.push(context, MaterialPageRoute(builder: (context) => ProfileScreen(userId: widget.userId,)));
    }
    */
    // If you *did* want to navigate to a new screen for Profile:
    // You might remove the ProfileScreen from the _pages list,
    // and in _onItemTapped, when index is 1, call Navigator.push.
    // But the current structure strongly implies swapping via the index.
  }

  // Function to build the content for the Home/Dashboard view
  // Make sure this function accepts BuildContext
  Widget _buildDashboardContent(BuildContext context) { // Added BuildContext context
    // This is the existing content of your DashboardScreen build method
    // It can now safely access MediaQuery.of(context) because it's called from the build method.
    return Column( // Assuming Column is the top level widget
      mainAxisAlignment: MainAxisAlignment.start, // Add mainAxisAlignment if needed
      crossAxisAlignment: CrossAxisAlignment.stretch, // Add crossAxisAlignment if needed
      children: [
        // --- Custom Header Section ---
        Container(
          // This line is now safe because buildDashboardContent is called from build()
          // We remove MediaQuery.of(context).padding.top to reduce the space at the very top.
          // The 16.0 ensures padding below the header content.
          // Adding MediaQuery.of(context).padding.top here would *add* space below the status bar,
          // but setting extendBodyBehindAppBar: true and using padding inside
          // is a common way to place content correctly below the status bar.
          padding: const EdgeInsets.only(top: 16.0, left: 16, right: 16, bottom: 16), // Adjusted top padding
          decoration: BoxDecoration(
            color: Colors.green[800], // Corrected color syntax
            gradient: LinearGradient(
              colors: [Colors.green[800]!, Colors.green[600]!], // Corrected color syntax
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center, // Vertically align children in the center
            children: [
              // --- App Logo ---
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                child: ClipOval(
                  child: Image.asset(
                    // REPLACE WITH YOUR LOGO IMAGE PATH
                    'assets/images/gso.png',
                    width: 55,
                    height: 55,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) =>
                    // Handle potential errors loading the image
                    // Optional, but good practice
                    Icon(Icons.account_circle, size: 55, color: Colors.grey), // Fallback icon
                  ),
                ),
              ),
              SizedBox(width: 16), // Spacer

              // --- Title and Subtitle ---
              Expanded( // Use Expanded to make the text take available space
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min, // Use min to wrap content vertically
                  children: [
                    Text(
                      'AMGCS',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Advanced Monitoring Garbage Collection System',
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.white70, // Using white70 for slightly transparent white
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 16), // Spacer

              // --- Notification Bell Icon ---
              IconButton(
                icon: Icon(Icons.notifications_outlined, color: Colors.white, size: 30),
                onPressed: () {
                  print("Notification bell tapped");
                  // TODO: Implement notification action (maybe navigate to alerts screen)
                  // Accessing alerts from your db dump might be needed here.
                },
              ),
            ],
          ),
        ),
        // --- End of Custom Header Section ---

        // --- Main Content Area (Flexible to fill remaining space) ---
        Expanded( // Expanded makes this Column take up the rest of the vertical space
          child: SingleChildScrollView( // Make the main content scrollable
            child: Padding(
              padding: const EdgeInsets.all(16.0), // Add padding around the content
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch, // Stretch children horizontally
                children: [
                  // --- Routes Card ---
                  Card(
                    elevation: 4.0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    child: InkWell( // Use InkWell for tappable effect
                      onTap: () {
                        print("Routes Card tapped");
                        // TODO: Navigate to Routes screen
                      },
                      borderRadius: BorderRadius.circular(10.0), // Match card shape
                      child: Padding(
                        padding: const EdgeInsets.all(16.0), // Padding inside the card
                        child: Row(
                          children: [
                            // Image - Keeping your original Image.asset call
                            Image.asset(
                              // REPLACE WITH YOUR ROUTES IMAGE
                                'assets/images/route.png',
                                width: 60,
                                height: 60,
                                // errorBuilder is optional, you can keep it or remove if not needed
                                errorBuilder: (context, error, stackTrace) =>
                                    Icon(Icons.map, size: 60, color: Colors.green[700])),
                            SizedBox(width: 16), // Spacer
                            Expanded( // Allows text to take available space
                              child: Text(
                                'Routes',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.w600),
                              ),
                            ),
                            Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey),
                          ],
                        ),
                      ),
                    ),
                  ),

                  SizedBox(height: 16), // Spacer

                  // --- Collection Card ---
                  Card(
                    elevation: 4.0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0)),
                    child: InkWell( // Use InkWell for tappable effect
                      onTap: () {
                        print("Collection Card tapped");
                        // TODO: Navigate to Collection screen
                      },
                      borderRadius: BorderRadius.circular(10.0), // Match card shape
                      child: Padding(
                        padding: const EdgeInsets.all(16.0), // Padding inside the card
                        child: Row(
                          children: [
                            // Image - Keeping your original Image.asset call
                            Image.asset(
                              // REPLACE WITH YOUR COLLECTION IMAGE
                                'assets/images/collection.png',
                                width: 60,
                                height: 60,
                                // errorBuilder is optional, you can keep it or remove if not needed
                                errorBuilder: (context, error, stackTrace) =>
                                    Icon(Icons.collections_bookmark, size: 60, color: Colors.green[700])),
                            SizedBox(width: 16), // Spacer
                            Expanded( // Allows text to take available space
                              child: Text(
                                'Collection',
                                style: TextStyle(
                                    fontSize: 18, fontWeight: FontWeight.w600),
                              ),
                            ),
                            Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey),
                          ],
                        ),
                      ),
                    ),
                  ),

                  // Add more cards or content here as needed
                ],
              ),
            ),
          ),
        ),
        // --- End of Main Content Area ---
      ],
    );
  }


  @override
  Widget build(BuildContext context) {
    // The body content is now managed by _selectedIndex
    return Scaffold(
      // Removed the AppBar entirely to remove the default title and height.
      appBar: null,
      // Allows the body content to extend up into the status bar area.
      // The top padding inside the header Container handles the status bar height correctly.
      extendBodyBehindAppBar: true,
      body: IndexedStack( // Use IndexedStack to keep the state of each page
        index: _selectedIndex,
        children: _pages(context), // Use the list generated with valid context
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[ // Use const for performance
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex, // Track the selected item state
        selectedItemColor: Colors.green[700],
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped, // Use the handler function
      ),
    );
  }
}