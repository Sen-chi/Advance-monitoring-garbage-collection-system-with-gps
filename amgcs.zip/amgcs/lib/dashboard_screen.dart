// lib/dashboard_screen.dart (CORRECTED AND COMPLETE)

import 'package:flutter/material.dart';
import 'services/api_service.dart';
import 'profile_screen.dart';
import 'routes_screen.dart';
// Added imports for background location tracking
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class DashboardScreen extends StatefulWidget {
  final int userId;
  final String deviceId;
  final String username;

  const DashboardScreen({
    super.key,
    required this.userId,
    required this.deviceId,
    required this.username,
  });

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0;
  Map<String, dynamic>? _userProfile;
  bool _isLoadingProfile = false;
  String? _profileError;

  // --- LOCATION LOGIC ---
  Timer? _sendMyLocationTimer;
  final String _serverIp = '192.168.100.39';
  late final String _apiBaseUrl;
  // --- END LOCATION LOGIC ---

  @override
  void initState() {
    super.initState();
    _fetchProfile();

    // Start sending location from the main dashboard
    _apiBaseUrl = 'http://$_serverIp/tracker/api';
    _startSendingMyLocation();
  }

  @override
  void dispose() {
    // Dispose the location timer when dashboard is closed
    _sendMyLocationTimer?.cancel();
    super.dispose();
  }

  void _onItemTapped(int index) {
    if (_selectedIndex != index) {
      setState(() {
        _selectedIndex = index;
      });
    }
  }

  // --- ALL OF THE LOCATION METHODS ARE NOW HERE ---
  Future<bool> _handleLocationPermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      debugPrint('Location services are disabled.');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Location services are disabled. Please enable GPS.')));
      }
      return false;
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        debugPrint('Location permissions are denied.');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Location permissions are denied.')));
        }
        return false;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      debugPrint('Location permissions are permanently denied.');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Location permissions are permanently denied, we cannot request permissions.')));
      }
      return false;
    }
    return true;
  }

  Future<void> _startSendingMyLocation() async {
    _sendMyLocationTimer = Timer.periodic(const Duration(seconds: 10), (timer) async {
      final hasPermission = await _handleLocationPermission();
      if (!hasPermission || !mounted) return;

      try {
        Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        String locationName = await _getLocationName(position.latitude, position.longitude);

        final response = await http.post(
          Uri.parse('$_apiBaseUrl/locations.php'),
          headers: {'Content-Type': 'application/json; charset=UTF-8'},
          body: jsonEncode(<String, dynamic>{
            'deviceId': widget.deviceId,
            'latitude': position.latitude,
            'longitude': position.longitude,
            'locationName': locationName,
            'username': widget.username,
          }),
        );

        if (response.statusCode == 200) {
          debugPrint('Location sent successfully from Dashboard for ${widget.deviceId}');
        } else {
          debugPrint('Failed to send location from Dashboard: ${response.statusCode}');
        }
      } catch (e) {
        debugPrint('Error sending location from Dashboard: $e');
      }
    });
  }

  Future<String> _getLocationName(double latitude, double longitude) async {
    try {
      List<Placemark> placemarks = await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        return [
          place.street,
          place.subLocality,
          place.locality,
          place.country
        ].where((element) => element != null && element.isNotEmpty).join(', ');
      }
      return 'Unknown location';
    } catch (e) {
      debugPrint('Error getting location name: $e');
      return 'Unknown location';
    }
  }
  // --- END OF LOCATION METHODS ---


  Future<void> _fetchProfile() async {
    setState(() {
      _isLoadingProfile = true;
      _profileError = null;
      _userProfile = null;
    });

    try {
      final profileData = await ApiService.fetchUserProfile(widget.userId);
      if(!mounted) return;
      setState(() {
        _userProfile = profileData;
        _isLoadingProfile = false;
      });
    } catch (e) {
      debugPrint('Error fetching profile: $e');
      if(!mounted) return;
      setState(() {
        _profileError = 'Failed to fetch profile: ${e.toString()}';
        _isLoadingProfile = false;
        _userProfile = null;
      });
    }
  }

  // --- THIS IS YOUR ORIGINAL UI CODE, NOW RESTORED ---
  Widget _buildDashboardContent(Map<String, dynamic>? profile) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 16, left: 16, right: 16, bottom: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green[800]!, Colors.green[600]!],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/gso.png',
                    width: 55,
                    height: 55,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(Icons.account_circle, size: 55, color: Colors.grey);
                    },
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      profile != null ? 'Welcome, ${profile['username'] ?? widget.username}' : 'AMGCS',
                      style: TextStyle(
                        fontSize: profile != null ? 18 : 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      profile != null ? '${profile['role'] ?? 'N/A'}' : 'Advanced Monitoring Garbage Collection System',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.white70,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.notifications, color: Colors.white, size: 30),
                onPressed: () {
                  debugPrint("Notification bell tapped");
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                if (_profileError != null)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Text(
                      _profileError!,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RoutesScreen(
                            deviceId: widget.deviceId,
                            username: widget.username,
                          ),
                        ),
                      );
                    },
                    borderRadius: BorderRadius.circular(10.0),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Image.asset(
                            'assets/images/route.png',
                            width: 60,
                            height: 60,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(Icons.map, size: 60, color: Colors.green[700]);
                            },
                          ),
                          const SizedBox(width: 16),
                          const Expanded(
                            child: Text(
                              'Routes',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: InkWell(
                    onTap: () {
                      debugPrint("Collection Card tapped");
                      // TODO: Navigate to Collection screen
                    },
                    borderRadius: BorderRadius.circular(10.0),
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Image.asset(
                            'assets/images/collection.png',
                            width: 60,
                            height: 60,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(Icons.collections_bookmark, size: 60, color: Colors.green[700]);
                            },
                          ),
                          const SizedBox(width: 16),
                          const Expanded(
                            child: Text(
                              'Collection',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _getBodyWidget() {
    if (_selectedIndex == 0) {
      if (_isLoadingProfile) {
        return const Center(child: CircularProgressIndicator());
      }
      return _buildDashboardContent(_userProfile);
    } else if (_selectedIndex == 1) {
      return ProfileScreen(userId: widget.userId);
    }
    return const Center(child: Text('Invalid screen selected'));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: _getBodyWidget(),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.green[700],
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}