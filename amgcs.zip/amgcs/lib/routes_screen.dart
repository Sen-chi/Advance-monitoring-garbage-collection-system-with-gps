// lib/routes_screen.dart (CORRECTED AND COMPLETE)

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';

class RoutesScreen extends StatefulWidget {
  final String deviceId;
  final String username;

  const RoutesScreen({super.key, required this.deviceId, required this.username});

  @override
  State<RoutesScreen> createState() => _RoutesScreenState();
}

class _RoutesScreenState extends State<RoutesScreen> {
  final MapController _mapController = MapController();
  List<Marker> _garbageTruckMarkers = [];
  Timer? _fetchLocationsTimer;

  LatLng _myCurrentLocation = LatLng(14.5995, 120.9842);

  final String _serverIp = '192.168.100.39';
  late final String _apiBaseUrl;

  @override
  void initState() {
    super.initState();
    _apiBaseUrl = 'http://$_serverIp/tracker/api';

    _initializeAndCenterMap();
    _fetchAndSetAllLocations();
    _fetchLocationsTimer = Timer.periodic(const Duration(seconds: 5), (timer) => _fetchAndSetAllLocations());
  }

  @override
  void dispose() {
    _fetchLocationsTimer?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  Future<void> _initializeAndCenterMap() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if(!serviceEnabled) return;
      LocationPermission permission = await Geolocator.checkPermission();
      if(permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;

      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      if (!mounted) return;
      setState(() {
        _myCurrentLocation = LatLng(position.latitude, position.longitude);
        _mapController.move(_myCurrentLocation, 15.0);
      });
    } catch(e) {
      debugPrint("Could not get initial location for map centering: $e");
    }
  }

  Future<void> _fetchAndSetAllLocations() async {
    try {
      final response = await http.get(Uri.parse('$_apiBaseUrl/locations.php'));
      if (!mounted || response.statusCode != 200) return;

      final List<dynamic> locationsData = json.decode(response.body);
      List<Marker> newMarkers = [];

      for (var loc in locationsData) {
        final String deviceId = loc['deviceId'];
        final double latitude = loc['latitude'];
        final double longitude = loc['longitude'];
        final DateTime timestamp = DateTime.parse(loc['timestamp']);
        final String locationName = loc['locationName'] ?? 'N/A';
        final String username = loc['username'] ?? 'N/A';

        newMarkers.add(
          Marker(
            width: 80.0,
            height: 80.0,
            point: LatLng(latitude, longitude),
            child: GestureDetector(
              onTap: () {
                _showTruckInfo(context, deviceId, latitude, longitude, timestamp, locationName, username);
              },
              child: Column(
                children: [
                  Icon(
                    Icons.local_shipping,
                    color: deviceId == widget.deviceId ? Colors.red : Colors.blue,
                    size: 40.0,
                  ),
                  Text(
                    deviceId,
                    style: const TextStyle(fontSize: 10, color: Colors.black),
                  ),
                ],
              ),
            ),
          ),
        );
      }

      if (!mounted) return;
      setState(() {
        _garbageTruckMarkers = newMarkers;
      });

    } catch (e) {
      debugPrint('Error fetching locations: $e');
    }
  }

  // --- THIS FUNCTION IS NOW FULLY RESTORED ---
  void _showTruckInfo(BuildContext context, String deviceId, double lat, double lng, DateTime timestamp, String locationName, String username) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Truck: $deviceId'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Driver: $username'),
              Text('Location: $locationName'),
              Text('Latitude: ${lat.toStringAsFixed(6)}'),
              Text('Longitude: ${lng.toStringAsFixed(6)}'),
              Text('Last Update: ${timestamp.toLocal().toString().split('.')[0]}'),
            ],
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  // --- THIS BUILD METHOD IS NOW FULLY RESTORED ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Garbage Truck Routes'),
        backgroundColor: Colors.green,
      ),
      body: FlutterMap(
        mapController: _mapController,
        options: MapOptions(
          initialCenter: _myCurrentLocation,
          initialZoom: 13.0,
          maxZoom: 18.0,
          minZoom: 5.0,
        ),
        children: [
          TileLayer(
            urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            subdomains: const ['a', 'b', 'c'],
            userAgentPackageName: 'com.yourcompany.amgcsapp',
          ),
          MarkerLayer(
            markers: _garbageTruckMarkers,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _initializeAndCenterMap,
        backgroundColor: Colors.green,
        child: const Icon(Icons.my_location),
      ),
    );
  }
}