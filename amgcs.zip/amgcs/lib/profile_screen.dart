import 'dart:convert';
import 'dart:io'; // For File (used on mobile)
import 'dart:typed_data'; // For Uint8List (used on web)
import 'package:flutter/foundation.dart'; // For kIsWeb
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as path;
import 'main.dart'; // Assuming main.dart contains LoginScreen

// Model to hold profile data
class UserProfile {
  final int userId;
  final String username;
  final String email;
  final String? firstName;
  final String? middleName;
  final String? lastName;
  final String? contactNumber;
  final String? profilePictureUrl;

  UserProfile({
    required this.userId,
    required this.username,
    required this.email,
    this.firstName,
    this.middleName,
    this.lastName,
    this.contactNumber,
    this.profilePictureUrl,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    final profileUrl = json['profile_picture_url'] ?? json['profile_picture_filename'];
    return UserProfile(
      userId: int.tryParse(json['user_id'].toString()) ?? 0,
      username: json['username'] as String,
      email: json['email'] as String,
      firstName: json['first_name'] as String?,
      middleName: json['middle_name'] as String?,
      lastName: json['last_name'] as String?,
      contactNumber: json['contact_number'] as String?,
      profilePictureUrl: profileUrl as String?,
    );
  }
}

class ProfileScreen extends StatefulWidget {
  final int userId;
  const ProfileScreen({super.key, required this.userId});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  UserProfile? _userProfile;
  bool _isLoading = false;
  String? _profileError;
  File? _pickedImageFile;
  Uint8List? _pickedImageBytes;

  final String _fetchProfileApiUrl = 'http://192.168.100.39/amgcs_app/profile.php';
  final String _uploadProfilePictureApiUrl = 'http://192.168.100.39/amgcs_app/upload_profile_picture.php';
  final String _imageBaseUrl = 'http://192.168.100.39/amgcs_app/uploads/profile_pictures/';

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    if (_isLoading) return;
    if (mounted) {
      setState(() {
        _isLoading = true;
        _profileError = null;
      });
    }

    try {
      // --- THIS IS ALREADY CORRECTLY CACHE-BUSTING THE JSON FETCH ---
      final response = await http.get(
        Uri.parse(_fetchProfileApiUrl).replace(queryParameters: {
          'user_id': widget.userId.toString(),
          'cache_bust': DateTime.now().millisecondsSinceEpoch.toString(), // Good for fetching fresh profile data
        }),
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        final body = jsonDecode(response.body);
        if (body['success'] == true && body['profile'] != null) {
          setState(() => _userProfile = UserProfile.fromJson(body['profile']));
        } else {
          setState(() => _profileError = body['message'] ?? 'Failed to load profile data.');
        }
      } else {
        setState(() => _profileError = 'Server error: ${response.statusCode}');
      }
    } catch (e) {
      if (mounted) setState(() => _profileError = 'Failed to connect to server: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _pickImage() async {
    if (_isLoading) return;
    final picker = ImagePicker();
    try {
      final pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);

      if (pickedFile != null) {
        if (kIsWeb) {
          final bytes = await pickedFile.readAsBytes();
          if (mounted) setState(() => _pickedImageBytes = bytes);
        } else {
          if (mounted) setState(() => _pickedImageFile = File(pickedFile.path));
        }
        await _uploadImage(pickedFile);
      } else {
        // User cancelled the picker
      }
    } catch (e) {
      if (mounted) {
        setState(() => _profileError = "Error picking image: ${e.toString()}");
      }
    }
  }

  Future<void> _uploadImage(XFile imageFile) async {
    if (mounted) {
      setState(() {
        _isLoading = true;
        _profileError = null;
      });
    }

    try {
      final request = http.MultipartRequest('POST', Uri.parse(_uploadProfilePictureApiUrl))
        ..fields['user_id'] = widget.userId.toString();

      if (kIsWeb) {
        request.files.add(http.MultipartFile.fromBytes('profile_picture', await imageFile.readAsBytes(), filename: imageFile.name));
      } else {
        request.files.add(await http.MultipartFile.fromPath('profile_picture', imageFile.path, filename: path.basename(imageFile.path)));
      }

      final response = await http.Response.fromStream(await request.send());

      if (!mounted) return;

      final body = jsonDecode(response.body);
      if (response.statusCode == 200 && body['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(body['message'] ?? 'Profile picture updated!')));
        setState(() {
          _pickedImageFile = null;
          _pickedImageBytes = null;
        });
        await _fetchProfileData(); // Refresh data to get new URL
      } else {
        setState(() => _profileError = body['message'] ?? 'A server error occurred.');
      }
    } catch (e) {
      if (mounted) setState(() => _profileError = 'Failed to upload picture: ${e.toString()}');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.green[700],
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading && _userProfile == null) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_profileError != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(_profileError!, style: const TextStyle(color: Colors.red, fontSize: 16), textAlign: TextAlign.center),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: _fetchProfileData, child: const Text('Retry')),
            ],
          ),
        ),
      );
    }

    if (_userProfile == null) {
      return const Center(child: Text('No profile data available.'));
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _buildProfileHeader(),
          const SizedBox(height: 20),
          _buildActionList(),
        ],
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Container(
      padding: const EdgeInsets.all(20.0),
      color: Colors.white,
      child: Column(
        children: [
          GestureDetector(
            onTap: _pickImage,
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: Colors.grey[300],
                  child: ClipOval(child: _buildProfileImage()),
                ),
                const CircleAvatar(
                  radius: 12,
                  backgroundColor: Colors.green,
                  child: Icon(Icons.edit, size: 14, color: Colors.white),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Text(
            '${_userProfile!.firstName ?? ''} ${_userProfile!.lastName ?? _userProfile!.username}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          Text(_userProfile!.email, style: const TextStyle(color: Colors.grey)),
          if (_userProfile!.contactNumber?.isNotEmpty == true)
            Text('Contact: ${_userProfile!.contactNumber!}', style: const TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildProfileImage() {
    if (_pickedImageBytes != null) {
      return Image.memory(_pickedImageBytes!, fit: BoxFit.cover, width: 80, height: 80);
    }
    if (_pickedImageFile != null) {
      return Image.file(_pickedImageFile!, fit: BoxFit.cover, width: 80, height: 80);
    }
    if (_userProfile?.profilePictureUrl?.isNotEmpty == true) {
      // --- MODIFIED LINE: Added cache-busting directly to the image URL ---
      final imageUrl =
          '${_imageBaseUrl}${_userProfile!.profilePictureUrl}?v=${DateTime.now().millisecondsSinceEpoch}';
      return Image.network(
        imageUrl,
        fit: BoxFit.cover,
        width: 80,
        height: 80,
        errorBuilder: (context, error, stackTrace) => Icon(Icons.account_circle, size: 80, color: Colors.grey[700]),
      );
    }
    return Icon(Icons.account_circle, size: 80, color: Colors.grey[700]);
  }

  Widget _buildActionList() {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          ListTile(
            leading: Icon(Icons.edit_outlined, color: Colors.grey[700]),
            title: const Text('Edit profile'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 18),
            onTap: () {  },
          ),
          const Divider(height: 0),
          ListTile(
            leading: const Icon(Icons.logout, color: Colors.redAccent),
            title: const Text('Log out', style: TextStyle(color: Colors.redAccent)),
            trailing: const Icon(Icons.arrow_forward_ios, size: 18),
            onTap: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
                    (Route<dynamic> route) => false,
              );
            },
          ),
        ],
      ),
    );
  }
}