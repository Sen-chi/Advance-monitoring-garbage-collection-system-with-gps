import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart' show kIsWeb; // For web
import 'dart:io' show Platform; // For mobile/desktop platforms

class ApiService {
  // *** IMPORTANT: Replace with your actual computer's IP and the base path ***
  // You found your IP is 192.168.1.65
  // Your login URL was http://192.168.1.65/amgcs app/login.php
  // So the base path is /amgcs app/ and the base URL should include this.

  // This IP must be accessible from your phone/emulator
  static const String _serverIp = '192.168.1.65'; // <-- Use YOUR computer's IP
  static const String _emulatorIp = '10.0.2.2'; // Standard Android emulator IP

  // The base URL including the directory path on your server
  static const String _baseUrlPath = '/amgcs app'; // <-- Use the directory path where your PHP files are

  // Determine the correct host based on the platform
  static String get _host {
    if (kIsWeb) {
      // If running in a web browser, 'localhost' works if the server is on the same machine
      return 'localhost'; // Or '127.0.0.1'
    } else if (Platform.isAndroid) {
      // *** FIX: Removed Platform.isEmulator as it doesn't exist. ***
      // You need to manually switch between _emulatorIp and _serverIp
      // depending on whether you are running on an emulator or a physical device.

      // If you are testing on a PHYSICAL ANDROID DEVICE (like your vivo 1901)
      // and your computer is on the same network:
      return _serverIp; // <-- Use the physical machine's IP (192.168.1.65)

      // If you are testing on an ANDROID EMULATOR:
      // return _emulatorIp; // <-- Uncomment this line and comment the above line

    } else if (Platform.isIOS) {
      // For iOS Simulator, 'localhost' works. For physical device, need _serverIp.
      // Again, simple dart:io Platform doesn't distinguish physical vs simulator easily.
      // Defaulting to the local network IP for consistency with physical Android.
      return _serverIp; // <-- Use the physical machine's IP (for physical iOS devices or simulators)
      // If testing on iOS simulator and _serverIp doesn't work, try 'localhost'

    } else {
      // Desktop platforms (Windows, MacOS, Linux)
      // 'localhost' often works if the server is on the same machine, otherwise use local IP
      return _serverIp; // <-- Default to local IP
    }
  }

  // Construct the full base URL including scheme, host, and base path
  static String get _fullBaseUrl {
    // Your login URL didn't specify a port, implying standard HTTP port 80.
    // If your server runs on a different port, uncomment the line below and add the port.
    // static const int _serverPort = 80; // <-- Change if your server uses a different port
    // return 'http://$_host:$_serverPort$_baseUrlPath';

    // Assuming port 80 (default HTTP) as per your login URL structure
    return 'http://$_host$_baseUrlPath';
  }


  // --- Profile Endpoint ---
  // This method now expects to be called AFTER login succeeds, with the obtained userId.
  static Future<Map<String, dynamic>> fetchUserProfile(int userId) async {
    // Construct the URL for the profile endpoint
    // Assumes profile.php expects user_id as a query parameter
    final String profileUrl = '$_fullBaseUrl/profile.php?user_id=$userId'; // <--- Ensure '/profile.php' is correct

    print('Fetching profile from: $profileUrl'); // Debug print

    try {
      final response = await http.get(Uri.parse(profileUrl));

      print('Profile fetch status: ${response.statusCode}'); // Debug print
      print('Profile fetch response body: ${response.body}'); // Debug print the response body

      if (response.statusCode == 200) {
        // Server returned 200 OK, parse the JSON response
        final Map<String, dynamic> responseBody = jsonDecode(response.body);

        // Check the 'success' key in the JSON response from profile.php
        if (responseBody['success'] == true) {
          // Backend explicitly reported success in the JSON body
          return responseBody['profile']; // Return the profile data part
        } else {
          // Backend returned 200, but indicated an error in its JSON body
          throw Exception('Backend reported error fetching profile: ${responseBody['message'] ?? 'Unknown error'}');
        }

      } else {
        // Server returned a non-200 status code (like 400, 404, 500)
        // The error message you saw (404) comes from this part
        throw Exception('Server error fetching profile: ${response.statusCode}');
      }
    } catch (e) {
      // Handle network errors (e.g., connection refused)
      print('Error fetching profile: $e'); // Debug print
      // Re-throw with a more specific message for the UI
      throw Exception('Failed to connect to server or network error fetching profile: $e');
    }
  }

  // --- Login Endpoint (Moved from main.dart) ---
  static Future<Map<String, dynamic>> login(String username, String password) async {
    final String loginUrl = '$_fullBaseUrl/login.php'; // <--- Ensure '/login.php' is correct

    print('Attempting login to: $loginUrl'); // Debug print

    try {
      final response = await http.post(
        Uri.parse(loginUrl),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'username': username,
          'password': password,
        }),
      );

      print('Login status: ${response.statusCode}'); // Debug print
      print('Login response body: ${response.body}'); // Debug print the login response body

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = jsonDecode(response.body);
        return responseBody; // Return the whole login response body
      } else {
        // Backend returned a non-200 status for the login attempt
        // Even if success is false, if it's 200, the main.dart login logic handles it.
        // But if it's *not* 200 (e.g., 500 server error), throw here.
        throw Exception('Server error during login: ${response.statusCode}');
      }
    } catch (e) {
      print('Error during login: $e'); // Debug print
      // Re-throw with a more specific message for the UI
      throw Exception('Failed to connect to server or network error during login: $e');
    }
  }
}