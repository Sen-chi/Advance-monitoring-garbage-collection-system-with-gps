import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io'; // For File

import 'package:image_picker/image_picker.dart'; // For image picking
import 'package:path/path.dart' as path; // For getting filename

import 'main.dart'; // Assuming main.dart is in the same directory (lib/)


// Model to hold profile data
class UserProfile {
  final int userId;
  final String username;
  final String email;
  final String? firstName;
  final String? middleName;
  final String? lastName;
  final String? contactNumber;
  final String? profilePictureUrl; // Added field

  UserProfile({
    required this.userId,
    required this.username,
    required this.email,
    this.firstName,
    this.middleName,
    this.lastName,
    this.contactNumber,
    this.profilePictureUrl,
  });

  // Factory constructor to create a UserProfile from a Map
  // This factory now expects the map containing the actual profile fields,
  // NOT the full API response body. The calling function (_fetchProfileData)
  // will extract the correct nested map.
  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      userId: int.tryParse(json['user_id'].toString()) ?? 0, // Handle potential string user_id
      username: json['username'] as String,
      email: json['email'] as String,
      firstName: json['first_name'] as String?,
      middleName: json['middle_name'] as String?,
      lastName: json['last_name'] as String?,
      contactNumber: json['contact_number'] as String?,
      profilePictureUrl: json['profile_picture_url'] as String?,
    );
  }
}

class ProfileScreen extends StatefulWidget {
  final int userId; // Pass the logged-in user ID to this screen

  const ProfileScreen({super.key, required this.userId});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  UserProfile? _userProfile;
  // --- FIX IS HERE ---
  // Change the initial value from true to false.
  // The logic inside _fetchProfileData will set it to true when it starts.
  bool _isLoading = false; // Start as false, will be set to true in _fetchProfileData
  // --- END FIX ---

  File? _pickedImageFile; // To hold the image file picked by the user
  String? _profileError; // Added the declaration for _profileError

  // --- Backend API URLs ---
  // !!! CHANGE THESE TO YOUR ACTUAL SERVER IP/DOMAIN !!!
  final String _fetchProfileApiUrl = 'http://192.168.1.65/amgcs app/profile.php'; // Corrected URL based on log
  final String _uploadProfilePictureApiUrl = 'http://192.168.1.65/amgcs app/upload_profile_picture.php';
  // Base URL for accessing uploaded images
  final String _imageBaseUrl = 'http://192.168.1.65/amgcs app/uploads/profile_pictures/'; // Make sure this matches your PHP script's save location

  @override
  void initState() {
    super.initState();
    // Call fetch here. _isLoading is initially false, so the guard in _fetchProfileData
    // will not prevent the first fetch from starting.
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    // --- Guard clause ---
    // This guard prevents *redundant* fetches if one is *already* in progress.
    // Since _isLoading starts as false, it won't trigger on the initial call from initState.
    // It will trigger if _fetchProfileData is called again (e.g. from the retry button)
    // while the previous call hasn't finished yet (_isLoading is still true).
    if (_isLoading) {
      print('DEBUG: _fetchProfileData aborted: already loading.');
      return;
    }

    // Set loading state *after* the guard check, *before* the async operation starts
    setState(() {
      _isLoading = true; // Now we set loading to true here to show the spinner for THIS fetch attempt.
      _profileError = null; // Clear previous errors
      // Keep existing _userProfile data visible while loading if it exists
    });


    try {
      // --- Change from http.post to http.get and add query parameter ---
      print('Fetching profile from: ${Uri.parse(_fetchProfileApiUrl).replace(queryParameters: {'user_id': widget.userId.toString()})}'); // Debug print
      final response = await http.get(
        Uri.parse(_fetchProfileApiUrl).replace(queryParameters: {
          'user_id': widget.userId.toString(), // Pass user_id as a query parameter
        }),
        // Remove headers and body for a standard GET request
      );
      print('Profile fetch status: ${response.statusCode}'); // Debug print
      print('Profile fetch response body: ${response.body}'); // Debug print


      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = jsonDecode(response.body);
        if (responseBody['success'] == true) {
          // --- Access the nested 'profile' map for parsing ---
          if (responseBody['profile'] != null && responseBody['profile'] is Map<String, dynamic>) {
            if (mounted) { // Check if widget is still in the tree before setState
              setState(() {
                _userProfile = UserProfile.fromJson(responseBody['profile']); // Pass the nested map to fromJson
                _profileError = null; // Clear error on success
              });
            }
          } else {
            // Handle case where success is true but 'profile' data is missing or not a map
            print('Failed to load profile: Success true but missing or invalid profile data.');
            if (mounted) {
              setState(() {
                _profileError = 'Failed to load profile data: Invalid format'; // Set specific error
                _userProfile = null; // Clear profile data on invalid format
              });
              // Only show Snackbar if the widget is still mounted
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(_profileError!)),
                );
              }
            }
          }
        } else {
          // Handle error fetching data where success is false (e.g. message indicates no user)
          print('Failed to load profile: ${responseBody['message']}');
          if (mounted) {
            setState(() {
              _profileError = responseBody['message'] ?? 'Failed to load profile data'; // Set specific error
              _userProfile = null; // Clear profile data on API error
            });
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(_profileError!)),
              );
            }
          }
        }
      } else {
        // Handle non-200 status codes (like 404, 405, 500)
        print('Server error fetching profile: ${response.statusCode}');
        if (mounted) {
          setState(() {
            _profileError = 'Server error: ${response.statusCode}'; // Set specific error
            _userProfile = null; // Clear profile data on server error
          });
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(_profileError!)),
            );
          }
        }
      }
    } catch (e) {
      // Handle network errors (e.g., no internet)
      print('Error fetching profile: $e');
      if (mounted) {
        setState(() {
          _profileError = 'Failed to connect to server: ${e.toString()}'; // Set specific error
          _userProfile = null; // Clear profile data on network error
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(_profileError!)),
          );
        }
      }
    } finally {
      // --- Hide loading indicator only if the widget is still mounted ---
      // This runs regardless of success or failure
      if (mounted) {
        setState(() {
          _isLoading = false; // Set loading state to false at the end
        });
      }
    }
  }

  Future<void> _pickImage() async {
    // Prevent picking image if already loading/uploading
    if (_isLoading) return;

    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80); // Added imageQuality

    if (pickedFile != null) {
      // Optionally set the picked image immediately for a preview while uploading
      setState(() {
        _pickedImageFile = File(pickedFile.path);
      });
      // Upload immediately after picking
      _uploadImage(File(pickedFile.path)); // Pass the actual File object
    } else {
      print('No image selected.');
      if (mounted) { // Show message if no image was selected
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No image selected.')),
        );
      }
    }
  }

  Future<void> _uploadImage(File imageFile) async {
    // Prevent uploading if already loading/fetching
    if (_isLoading) return;

    setState(() {
      _isLoading = true; // Show loading indicator during upload
      _profileError = null; // Clear previous errors
    });

    try {
      // Create a multipart request
      var request = http.MultipartRequest(
        'POST',
        Uri.parse(_uploadProfilePictureApiUrl),
      );

      // Add the user ID field
      request.fields['user_id'] = widget.userId.toString();

      // Add the image file
      request.files.add(await http.MultipartFile.fromPath(
        'profile_picture', // This should match the name expected by your PHP script ($_FILES['profile_picture'])
        imageFile.path,
        filename: path.basename(imageFile.path), // Use the original filename
      ));

      // Send the request
      var streamedResponse = await request.send();

      // Listen for the response
      var response = await http.Response.fromStream(streamedResponse);

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseBody = jsonDecode(response.body);
        if (responseBody['success'] == true) {
          print('Profile picture uploaded successfully!');
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(responseBody['message'] ?? 'Profile picture updated!')),
            );
          }
          // Refresh profile data to show the new image URL from the backend
          // Calling _fetchProfileData here will work because _isLoading will be false
          // after the finally block below runs for the upload.
          _fetchProfileData();
          // Clear the picked image file state after the upload starts
          setState(() {
            _pickedImageFile = null;
          });

        } else {
          print('Failed to upload profile picture: ${responseBody['message']}');
          if (mounted) {
            setState(() {
              _profileError = responseBody['message'] ?? 'Failed to upload picture';
            });
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(_profileError!)),
              );
            }
          }
        }
      } else {
        print('Server error uploading picture: ${response.statusCode}');
        if (mounted) {
          setState(() {
            _profileError = 'Server error uploading picture: ${response.statusCode}';
          });
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(_profileError!)),
            );
          }
        }
      }
    } catch (e) {
      print('Error uploading picture: $e');
      if (mounted) {
        setState(() {
          _profileError = 'Failed to upload picture: ${e.toString()}';
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(_profileError!)),
          );
        }
      }
    } finally {
      // Hide loading indicator regardless of upload success/failure
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }


  @override
  Widget build(BuildContext context) {
    // Determine which image source to use (picked image, fetched URL, or default)
    // This should be determined based on the *loaded* _userProfile data, unless a new image was picked
    Widget profileImageWidget;

    // Prioritize the image picked by the user before checking fetched data
    // _pickedImageFile will only be non-null momentarily while an upload is pending
    if (_pickedImageFile != null) {
      profileImageWidget = Image.file(_pickedImageFile!, fit: BoxFit.cover);
    }
    // Then check if _userProfile data is loaded and has a picture URL
    else if (_userProfile != null && _userProfile!.profilePictureUrl != null && _userProfile!.profilePictureUrl!.isNotEmpty) {
      profileImageWidget = Image.network(
        '$_imageBaseUrl${_userProfile!.profilePictureUrl}', // Construct the full URL
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          // Fallback if network image fails or URL is invalid
          print('Error loading profile image: $error'); // Log image loading errors
          return Icon(Icons.account_circle, size: 80, color: Colors.grey[700]);
        },
      );
    }
    // Default icon if no picked image, no profile data yet, or no picture URL in profile data
    else {
      profileImageWidget = Icon(Icons.account_circle, size: 80, color: Colors.grey[700]); // Default icon
    }


    // --- Determine the body content based on loading/error/data states ---
    Widget bodyContent;

    // If currently loading, show the loading indicator.
    // _isLoading is true during fetch and upload operations.
    if (_isLoading) {
      bodyContent = const Center(child: CircularProgressIndicator()); // Show loading spinner

    }
    // If not loading, check for errors.
    else if (_profileError != null) {
      bodyContent = Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 50),
              const SizedBox(height: 10),
              Text(
                _profileError ?? 'Unable to load profile data.',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.red, fontSize: 16),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _fetchProfileData, // Retry fetching data
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }
    // If not loading and no errors, check if we have data to display.
    // This condition will be true if _userProfile is not null (data loaded)
    // OR if _pickedImageFile is not null (user picked a local image, potentially while waiting for upload).
    // Since _pickedImageFile is cleared after upload starts, the main condition is _userProfile != null.
    else if (_userProfile != null) { // Changed condition slightly to rely on _userProfile being loaded
      // Show profile details if we have fetched data
      bodyContent = SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            // --- Profile Header Section ---
            Container(
              padding: const EdgeInsets.all(20.0),
              color: Colors.white, // White background for the header section
              child: Column(
                children: [
                  GestureDetector( // Make the profile picture tappable
                    onTap: _pickImage, // Call the image picker function
                    child: Stack( // Use Stack to layer the image and edit icon
                      alignment: Alignment.bottomRight,
                      children: [
                        CircleAvatar(
                          radius: 40, // Adjust size as needed
                          backgroundColor: Colors.grey[300], // Placeholder background
                          child: ClipOval( // Clip the image to a circle
                            child: profileImageWidget, // The widget determined above
                          ),
                        ),
                        // Optional: Add an edit icon overlay
                        const Positioned( // Use const
                          right: 0,
                          bottom: 0,
                          child: CircleAvatar(
                            radius: 12,
                            backgroundColor: Colors.green, // Use green directly or green[700] if preferred
                            child: Icon(Icons.edit, size: 14, color: Colors.white), // Use const
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10), // Use const
                  Text(
                    // Display Full Name if available, otherwise Username
                    // Use null-aware access (?.) and null-coalescing (??) safely
                    // _userProfile is guaranteed not null here due to the outer else-if condition
                    (_userProfile!.firstName != null && _userProfile!.lastName != null && _userProfile!.firstName!.isNotEmpty && _userProfile!.lastName!.isNotEmpty)
                        ? '${_userProfile!.firstName!} ${_userProfile!.middleName != null && _userProfile!.middleName!.isNotEmpty ? '${_userProfile!.middleName!} ' : ''}${_userProfile!.lastName!}'
                        : (_userProfile!.username), // Fallback to username if _userProfile is not null
                    style: const TextStyle( // Use const
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  Text(
                    _userProfile!.email, // email is non-nullable in UserProfile
                    style: const TextStyle( // Use const
                      fontSize: 14,
                      color: Colors.grey, // Use grey directly or grey[600] if preferred
                    ),
                  ),
                  // Display contact number if available
                  if (_userProfile!.contactNumber != null && _userProfile!.contactNumber!.isNotEmpty) // Also check if not empty
                    Text(
                      'Contact: ${_userProfile!.contactNumber!}',
                      style: const TextStyle( // Use const
                        fontSize: 14,
                        color: Colors.grey, // Use grey directly or grey[600] if preferred
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20), // Space after header // Use const

            // --- Profile Options List ---
            Container(
              color: Colors.white, // White background for the list section
              child: Column( // Use Column for ListTiles
                children: [

                  const Divider(height: 0), // Visual separator // Use const

                  // Edit Profile Tile
                  ListTile(
                    leading: Icon(Icons.edit_outlined, color: Colors.grey[700]),
                    title: const Text('Edit profile'), // Use const
                    trailing: const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey), // Use const
                    onTap: () {
                      // TODO: Navigate to Edit Profile screen
                      print("Edit profile tapped");
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Edit profile (Not implemented, you can add fields here)')), // Use const
                        );
                      }
                      // A dedicated EditProfileScreen would be better for editing text fields
                      // For now, picture upload is handled directly here via tapping the image.
                    },
                  ),
                  const Divider(height: 0), // Use const

                  // Notifications Tile
                  ListTile(
                    leading: Icon(Icons.notifications_outlined, color: Colors.grey[700]),
                    title: const Text('Notifications'), // Use const
                    trailing: const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey), // Use const
                    onTap: () {
                      // TODO: Navigate to Notifications settings
                      print("Notifications tapped");
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Notification settings (Not implemented)')), // Use const
                        );
                      }
                    },
                  ),
                  const Divider(height: 0), // Use const

                  // Log out Tile
                  ListTile(
                    leading: const Icon(Icons.logout, color: Colors.redAccent), // Different color for logout // Use const
                    title: const Text('Log out', style: TextStyle(color: Colors.redAccent)), // Use const
                    trailing: const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey), // Use const
                    onTap: () {
                      // TODO: Implement Log out logic
                      print("Log out tapped");
                      // Clear any stored session data (like user ID, tokens)
                      // Navigate back to the LoginScreen
                      if (mounted) {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => LoginScreen()), // LoginScreen should be accessible
                              (Route<dynamic> route) => false, // Remove all previous routes
                        );
                      }
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
    // Fallback - Should theoretically not be reached if logic is sound, but good for debugging
    else {
      // This state means _isLoading is false, _profileError is null, and _userProfile is null.
      // This implies _fetchProfileData ran, completed without error, but _userProfile is null
      // which shouldn't happen with a successful fetch. Could indicate an empty 'profile'
      // in the API response even if success is true (which your current error handling covers,
      // but this is a fallback).
      bodyContent = const Center(child: Text('No profile data available.')); // Use const
    }


    return Scaffold(
      // Using AppBar for a standard screen header
      appBar: AppBar(
        title: const Text( // Use const
          'Profile',
          style: TextStyle(color: Colors.white), // <-- Set text color to white
        ),
        backgroundColor: Colors.green[700], // Match theme color
        iconTheme: const IconThemeData(color: Colors.white), // Ensure back button/other icons are white if needed // Use const
      ),
      // --- Use the determined bodyContent ---
      body: bodyContent,
    );
  }
}

// Ensure you have a LoginScreen in main.dart or imported correctly.
// Ensure your ApiService.dart file exists and has fetchUserProfile and potentially uploadProfilePicture methods.