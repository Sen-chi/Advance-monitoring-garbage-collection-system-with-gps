import 'package:flutter/material.dart';
// Import the ApiService - make sure this file exists at lib/services/api_service.dart
import 'services/api_service.dart';

// Import your dashboard screen file - make sure this file exists
import 'dashboard_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AMGCS App', // Changed title
      // Start with the LoginScreen
      home: LoginScreen(), // Refers to the LoginScreen StatefulWidget below
      debugShowCheckedModeBanner: false,
    );
  }
}

// --- LoginScreen StatefulWidget definition (Added this back) ---
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}
// --- End of LoginScreen definition ---


// --- _LoginScreenState definition (Ensured methods and variables are inside) ---
class _LoginScreenState extends State<LoginScreen> { // Correct start of the State class
  // Variables and Controllers must be inside the class
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _isLoading = false;

  // --- Function to handle Login (Must be inside the class) ---
  Future<void> _login() async {
    setState(() {
      _isLoading = true; // Show loading indicator
    });

    final String username = _usernameController.text.trim();
    final String password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter username and password')),
      );
      setState(() {
        _isLoading = false;
      });
      return; // Stop if fields are empty
    }

    try {
      // --- Call the login method from ApiService ---
      // Ensure ApiService.login is implemented correctly and uses the right URL (your computer's IP)
      final responseBody = await ApiService.login(username, password);

      setState(() {
        _isLoading = false; // Hide loading indicator
      });

      if (responseBody['success'] == true) {
        print('Login Successful!');
        final int? userId = responseBody['user_id'];

        if (userId != null) {
          // Navigate to the DashboardScreen and pass the user ID
          // Ensure DashboardScreen constructor accepts userId
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => DashboardScreen(userId: userId), // Pass the obtained user ID
            ),
          );
        } else {
          print('Login successful, but user ID not received.');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Login successful, but user data incomplete. Please contact support.')),
          );
        }
      } else {
        // Login failed (backend reported error based on success: false)
        final String errorMessage = responseBody['message'] ?? 'Login failed';
        print('Login Failed: $errorMessage');
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage)),
        );
      }
    } catch (e) {
      // Handle network errors or exceptions thrown by ApiService.login
      print('Error during login: $e');
      setState(() {
        _isLoading = false; // Ensure loading is off even on error
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to connect to server or login error: $e')), // Show the specific error message from the catch
      );
    }
  }
  // --- End of Login Function ---


  @override
  void dispose() { // Dispose method must be inside the class
    // Clean up the controllers when the widget is disposed
    _usernameController.dispose(); // These are defined inside this class
    _passwordController.dispose(); // These are defined inside this class
    super.dispose();
  }

  @override
  Widget build(BuildContext context) { // Build method must be inside the class
    // --- This is the actual Login Screen UI code ---
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Center(
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/gso.png', // Make sure this path is correct in your project
                      width: 150,
                      height: 150,
                      // Handle potential errors loading the image (optional, but good practice)
                      errorBuilder: (context, error, stackTrace) {
                        return Icon(Icons.account_circle, size: 150, color: Colors.grey); // Fallback icon
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 40.0),

                TextField(
                  controller: _usernameController, // Defined inside this class
                  decoration: InputDecoration(
                    hintText: 'Username',
                    filled: true,
                    fillColor: Colors.grey[200],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                  ),
                ),
                const SizedBox(height: 15.0),

                TextField(
                  controller: _passwordController, // Defined inside this class
                  obscureText: true,
                  decoration: InputDecoration(
                    hintText: 'Password',
                    filled: true,
                    fillColor: Colors.grey[200],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 15.0),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                  ),
                ),
                const SizedBox(height: 25.0),

                ElevatedButton(
                  onPressed: _isLoading ? null : _login, // Use _login method defined inside this class
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green[700],
                    padding: const EdgeInsets.symmetric(vertical: 15.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                  child: _isLoading // Use _isLoading variable defined inside this class
                      ? SizedBox(
                    height: 24,
                    width: 24,
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white), // FIXED: value color -> valueColor
                      strokeWidth: 2.0,
                    ),
                  )
                      : const Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
                const SizedBox(height: 20.0),

              ],
            ),
          ),
        ),
      ),
      // --- End of the actual Login Screen UI code ---
    );
  }
} // Correct closing brace for the _LoginScreenState class
// --- End of _LoginScreenState definition ---

// The DashboardScreen definition is expected to be in dashboard_screen.dart
// It should accept an 'userId' argument in its constructor.