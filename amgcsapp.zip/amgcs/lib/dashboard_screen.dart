import 'package:flutter/material.dart';
// Import the ApiService - make sure this file exists at lib/services/api_service.dart
import 'services/api_service.dart';
// Import the Profile Screen - make sure this file exists
import 'profile_screen.dart'; // Assuming you have a profile_screen.dart

class DashboardScreen extends StatefulWidget {
  final int userId; // Accept user ID passed from LoginScreen

  const DashboardScreen({Key? key, required this.userId}) : super(key: key);

  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _selectedIndex = 0; // To track selected bottom nav item
  Map<String, dynamic>? _userProfile; // To store the fetched profile data
  bool _isLoadingProfile = false;
  String? _profileError;

  @override
  void initState() {
    super.initState();
    _fetchProfile(); // Fetch profile when the screen initializes
  }

  // Function to handle bottom navigation bar taps
  void _onItemTapped(int index) {
    // Only update if the index is different to avoid unnecessary rebuilds
    if (_selectedIndex != index) {
      setState(() {
        _selectedIndex = index; // Update selected index
      });
    }
  }

  // Function to fetch user profile from the backend
  Future<void> _fetchProfile() async {
    setState(() {
      _isLoadingProfile = true;
      _profileError = null; // Clear previous errors
      _userProfile = null; // Clear previous profile data
    });

    try {
      // Call the fetchUserProfile method from ApiService, passing the user ID
      final profileData = await ApiService.fetchUserProfile(widget.userId);

      setState(() {
        _userProfile = profileData; // Store the fetched profile data
        _isLoadingProfile = false;
      });

    } catch (e) {
      print('Error fetching profile: $e'); // Log the error
      setState(() {
        // Set the error message to be displayed
        _profileError = 'Failed to fetch profile: ${e.toString()}';
        _isLoadingProfile = false;
        _userProfile = null; // Clear profile data on error
      });
    }
  }

  // Function to build the content for the Home/Dashboard view
  // This now includes the custom header and the scrollable card area below it.
  Widget _buildDashboardContent(Map<String, dynamic>? profile) {
    // This method is called from the build method via _getBodyWidget,
    // so it's safe to use MediaQuery.of(context) here.
    return Column(
      mainAxisAlignment: MainAxisAlignment.start, // Align content to the top
      crossAxisAlignment: CrossAxisAlignment.stretch, // Stretch children horizontally
      children: <Widget>[
        // --- Custom Header Section (Brought back) ---
        Container(
          // Add top padding to account for status bar height when AppBar is removed
          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 16, left: 16, right: 16, bottom: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.green[800]!, Colors.green[600]!],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              // App Logo
              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/gso.png', // <- REPLACE WITH YOUR LOGO IMAGE PATH
                    width: 55,
                    height: 55,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return Icon(Icons.account_circle, size: 55, color: Colors.grey); // Fallback icon
                    },
                  ),
                ),
              ),
              SizedBox(width: 16),

              // Title and Subtitle (User Greeting)
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      // Use the fetched profile username if available, otherwise a placeholder
                      profile != null ? 'Welcome, ${profile['username'] ?? 'User'}' : 'AMGCS',
                      style: TextStyle(
                        fontSize: profile != null ? 18 : 24, // Smaller size for welcome
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ), // ADDED COMMA HERE
                    Text(
                      profile != null ? '${profile['role'] ?? 'N/A'}' : 'Advanced Monitoring Garbage Collection System', // Removed 'Role: ' prefix
                      style: TextStyle(
                        fontSize: profile != null ? 14 : 12, // Adjust size
                        color: Colors.white70,
                      ), // <-- Correctly closing style and adding comma
                      overflow: TextOverflow.ellipsis, // <-- Moved inside Text constructor
                    ), // <-- Correctly closing Text widget
                  ],
                ),
              ),

              // Notification Bell Icon (remains in custom header as in original image)
              IconButton(
                icon: Icon(Icons.notifications, color: Colors.white, size: 30),
                onPressed: () {
                  print("Notification bell tapped");
                  // TODO: Implement notification action (maybe navigate to alerts screen)
                },
              ),
            ],
          ),
        ),
        // --- End of Custom Header Section ---

        // --- Main Content Area (Flexible and Scrollable) ---
        Expanded( // Use Expanded to make this area take up the remaining vertical space
          child: SingleChildScrollView( // Make the content below the header scrollable
            padding: const EdgeInsets.all(16.0), // Add padding around the scrollable content
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                if (_profileError != null) // Show error message if fetching failed
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Text(
                      _profileError!,
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                // --- Routes Card ---
                Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: InkWell( // Use InkWell for tap effect
                    onTap: () {
                      // TODO: Navigate to Routes screen
                      print("Routes Card tapped");
                    },
                    borderRadius: BorderRadius.circular(10.0), // Match InkWell border radius
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Image.asset(
                            'assets/images/route.png', // <- REPLACE WITH YOUR ROUTES IMAGE
                            width: 60,
                            height: 60,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(Icons.map, size: 60, color: Colors.green[700]); // Fallback icon
                            },
                          ),
                          SizedBox(width: 16), // Spacing between image and text
                          Expanded( // Text takes remaining space
                            child: Text(
                              'Routes',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                          ),
                          Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey), // Forward icon
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 16), // Space between cards

                // --- Collection Card ---
                Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: InkWell( // Use InkWell for tap effect
                    onTap: () {
                      // TODO: Navigate to Collection screen
                      print("Collection Card tapped");
                    },
                    borderRadius: BorderRadius.circular(10.0), // Match InkWell border radius
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        children: [
                          Image.asset(
                            'assets/images/collection.png', // <- REPLACE WITH YOUR COLLECTION IMAGE
                            width: 60,
                            height: 60,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(Icons.collections_bookmark, size: 60, color: Colors.green[700]); // Fallback icon
                            },
                          ),
                          SizedBox(width: 16), // Spacing
                          Expanded( // Text takes remaining space
                            child: Text(
                              'Collection',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                            ),
                          ),
                          Icon(Icons.arrow_forward_ios, size: 20, color: Colors.grey), // Forward icon
                        ],
                      ),
                    ),
                  ),
                ),
                // Add more cards or content here as needed
              ],
            ),
          ),
        ),
        // --- End of Main Content Area ---
      ],
    );
  }


  // Helper function to get the body widget based on the selected index
  Widget _getBodyWidget() {
    if (_selectedIndex == 0) {
      // If index is 0, show the dashboard content
      if (_isLoadingProfile) {
        // Show loading indicator for the main body area below where the AppBar *would* be
        // Since we removed the AppBar, maybe show a simple loading in the center of the screen
        return Center(child: CircularProgressIndicator());
      }
      // Otherwise, build and show the dashboard content with fetched profile or error message.
      // The _buildDashboardContent now includes the custom header and the scrollable cards.
      return _buildDashboardContent(_userProfile);
    } else if (_selectedIndex == 1) {
      // If index is 1, show the ProfileScreen
      // Note: ProfileScreen itself might have an AppBar, which is fine.
      return ProfileScreen(userId: widget.userId);
    }
    // Default or fallback widget if needed
    return Center(child: Text('Invalid screen selected'));
  }


  @override
  Widget build(BuildContext context) {
    // The main build method defines the overall structure (Scaffold, BottomNav)
    // and dynamically sets the body.
    // We set appBar to null to remove the default AppBar.

    return Scaffold(
      // --- REMOVED STANDARD APP BAR ---
      appBar: null, // Set appBar to null to remove the "AMGCS Dashboard" bar


      // --- Body content is now dynamically determined by _getBodyWidget ---
      // This body will start from the top below the status bar because appBar is null.
      body: _getBodyWidget(),


      // --- Bottom Navigation Bar ---
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[ // Use const for static items
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: _selectedIndex, // Highlight the currently selected item
        selectedItemColor: Colors.green[700],
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped, // Use the handler function
      ),
      // --- End of Bottom Navigation Bar ---
    );
  }
}

// Ensure you have a ProfileScreen.dart file with a ProfileScreen widget
// like the placeholder provided in your original code block if needed.
/*
import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  final int userId;
  const ProfileScreen({Key? key, required this.userId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold( // Note: This ProfileScreen example also returns a Scaffold, which is fine when it's the main body of *another* Scaffold.
      appBar: AppBar(
        title: Text('Profile'),
        backgroundColor: Colors.blueAccent, // Different color to distinguish
      ),
      body: Center(
        child: Text('Profile Screen for User ID: $userId'),
      ),
    );
  }
}
*/